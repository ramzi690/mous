package com.example.note.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.note.R;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import com.example.note.controller.NoteController;

public class MainActivity extends AppCompatActivity {
    private NoteController noteController = new NoteController();
    private NoteAdapter noteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText titleEditText = findViewById(R.id.titleEditText);
        EditText contentEditText = findViewById(R.id.contentEditText);
        Button addNoteButton = findViewById(R.id.addNoteButton);
        ListView noteListView = findViewById(R.id.noteListView);

        noteAdapter = new NoteAdapter(this, noteController.getNotes());
        noteListView.setAdapter(noteAdapter);

        addNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString();
                String content = contentEditText.getText().toString();

                noteController.addNote(title, content);
                noteAdapter.notifyDataSetChanged();

                titleEditText.getText().clear();
                contentEditText.getText().clear();
            }
        });
    }
}
