package com.example.note.controller;

import java.util.ArrayList;
import java.util.List;
import com.example.note.model.Note;
public class NoteController {
    private List<Note> notes = new ArrayList<>();

    public void addNote(String title, String content) {
        Note newNote = new Note(title, content);
        notes.add(newNote);
    }

    public List<Note> getNotes() {
        return notes;
    }
}
